var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.ForceTwoStepVerification"] = {"ForceTwoStepVerification.Action":"Configuración","ForceTwoStepVerification.Body":"Debes configurar la verificación en pasos para completar esta acción. Esto ayudará a proteger tu inicio de sesión, tus compras y más.","ForceTwoStepVerification.Header":"Verificación en dos pasos obligatoria"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ForceTwoStepVerification");

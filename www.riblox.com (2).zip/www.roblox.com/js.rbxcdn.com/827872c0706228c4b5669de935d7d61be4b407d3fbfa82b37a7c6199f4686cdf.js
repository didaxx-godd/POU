var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.RostileChallenge"] = {"Description.VerificationSuccess":"Verificación completada","Description.VerificationError":"La verificación falló debido a un problema. Vuelve a intentarlo.","Description.VerificationPrompt":"Para proceder, primero verifica que eres humano.","Description.VerificationHeader":"Verificación completa","Description.VerificationErrorHeader":"Verificación fallida","Description.Ok":"Aceptar","Description.ImAHuman":"Empezar verificación"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.RostileChallenge");

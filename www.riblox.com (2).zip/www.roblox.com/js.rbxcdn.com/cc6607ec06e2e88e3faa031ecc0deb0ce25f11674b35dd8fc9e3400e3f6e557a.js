var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Authentication.LogoutModal"] = {"Heading.SignedOut":"You're signed out","Body.SignedOutGeneric":"You are signed out. To continue, sign in again and retry.","Body.SignedOutSecurity":"We signed you out for your security.","Action.SignIn":"Sign in","Body.SignInCTA":"Sign in again and retry."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Authentication.LogoutModal");

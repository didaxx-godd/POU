var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Authentication.Captcha"] = {"Action.Reload":"Recargar","Action.Submit":"Enviar","Response.CaptchaNotEnteredError":"Completa el desafío Captcha","Header.PleaseConfirmYouAreHuman":"Confirma que eres humano","Message.Error.Default":"Se produjo un error desconocido al mostrar el captcha.","Action.PleaseTryAgain":"Inténtalo de nuevo.","Header.RobotChallenge":"Desafío robot","Description.VerifyingYouAreNotBot":"Verificando que no eres un robot"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Authentication.Captcha");

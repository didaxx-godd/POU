var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.ProofOfWorkChallenge"] = {"Description.VerifyingYouAreNotBot":"Verificar que no eres un robot","Description.VerificationSuccess":"Verificación completada.","Description.VerificationError":"Se produjo un error. Inténtalo de nuevo. "};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ProofOfWorkChallenge");

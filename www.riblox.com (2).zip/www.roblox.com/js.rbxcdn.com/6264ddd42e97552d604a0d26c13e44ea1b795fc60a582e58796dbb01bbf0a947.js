var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Common.Captcha"] = {"Response.CaptchaErrorVerifyFailed":"Error temporal. Inténtalo de nuevo en unos minutos","Response.CaptchaErrorFailedToLoad":"Necesitamos verificar que eres humano. Desactiva el bloqueador de navegador y actualiza la página, o prueba a usar otro navegador.","Response.CaptchaErrorFailedToVerify":"Error temporal. Inténtalo de nuevo en unos minutos."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Common.Captcha");

var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Common.Captcha"] = {"Response.CaptchaErrorVerifyFailed":"Temporary error. Please try again in a few minutes","Response.CaptchaErrorFailedToLoad":"We need to verify that you are human. Please disable your browser blocker and refresh the page, or try a different browser.","Response.CaptchaErrorFailedToVerify":"Temporary error. Please try again in a few minutes."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Common.Captcha");

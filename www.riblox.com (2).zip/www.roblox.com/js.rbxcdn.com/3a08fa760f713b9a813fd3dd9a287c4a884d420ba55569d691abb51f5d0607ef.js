var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.EmailVerificationChallenge"] = {"Header.EnterCode":"Enter Verification Code","Header.VerifyYourAccount":"To proceed, verify your email","Description.SuspiciousActivityEmailVerification":"This is to confirm that you are human","Description.EnterCode":"Enter the code we just sent to your email.","Header.ConfirmAbandon":"Quit verification?","Description.ConfirmAbandon":"If you quit verification, you won't be able to complete this action.","Label.ConfirmAbandon":"Quit","Label.RejectAbandon":"Go back"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.EmailVerificationChallenge");

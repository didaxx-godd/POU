var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.PhoneVerificationChallenge"] = {"Description.ConfirmAbandon":"Si sales de la verificación, no podrás completar esta acción.","Label.RejectAbandon":"Volver","Label.ConfirmAbandon":"Salir","Header.ConfirmAbandon":"¿Salir de la verificación?"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.PhoneVerificationChallenge");

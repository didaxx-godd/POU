var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Common.Presence"] = {"Label.Online":"En línea","Label.Offline":"Sin conexión","Label.Playing":"Activos","Label.Creating":"Creando","Label.PlayingGame":"Se unió a {placeName}","Label.CreatingGame":"Creando en {placeName}","Label.Invisible":"Invisible"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Common.Presence");

var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.ProofOfSpaceChallenge"] = {"Description.VerificationSuccess":"Verificación completada.","Description.VerifyingYouAreNotBot":"Verificando que no eres un robot","Description.VerificationError":"Se produjo un error. Inténtalo de nuevo."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ProofOfSpaceChallenge");

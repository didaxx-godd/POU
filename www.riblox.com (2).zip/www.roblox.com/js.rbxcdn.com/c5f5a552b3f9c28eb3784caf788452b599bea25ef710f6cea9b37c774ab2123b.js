var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.BiometricChallenge"] = {"Title.ConfirmHuman":"Confirme que es humano","Content.LivenessHostedPrompt":"Abre tu navegador externo y hazte una selfie rápida para confirmar que eres humano.","Action.Continue":"Continuar","Action.Cancel":"Cancelar","Content.Loading":"Cargando..."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.BiometricChallenge");

var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.DeviceIntegrityChallenge"] = {"Description.VerificationError":"Some errors occurred. Please try again.","Description.VerificationSuccess":"Verification Completed.","Description.VerifyingYouAreNotBot":"Verifying you're not a bot"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.DeviceIntegrityChallenge");

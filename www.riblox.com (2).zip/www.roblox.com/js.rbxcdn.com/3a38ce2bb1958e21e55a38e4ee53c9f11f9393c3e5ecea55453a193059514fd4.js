var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.DeviceIntegrityChallenge"] = {"Description.VerificationError":"Se produjo un error. Inténtalo de nuevo.","Description.VerificationSuccess":"Verificación completada.","Description.VerifyingYouAreNotBot":"Verificando que no eres un robot"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.DeviceIntegrityChallenge");

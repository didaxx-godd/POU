var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.AgeVerificationUpsell"] = {"Modal.Title":"Age Verification Required","Modal.ContentText":"Verify your age to access this experience.\n\n1. Go to Account Info > Verify My Age\n2. Complete the verification process\n","Button.Cancel":"Cancel","Button.Settings":"Verify My Age","Button.AccountInfo":"Verify My Age","Modal.ContentTextWeb":"Please verify your age to access this experience.{lineBreak}{lineBreak}1. Go to Account Info in Settings{lineBreak}2. Choose Verify My Age{lineBreak}3. Complete the process"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.AgeVerificationUpsell");

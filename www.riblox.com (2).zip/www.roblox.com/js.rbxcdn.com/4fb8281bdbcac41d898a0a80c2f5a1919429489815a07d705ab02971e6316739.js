var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.ForceAuthenticator"] = {"Header.TurnOnAuthenticator":"Activar Autenticador","Description.SetupAuthenticator":"Debes configurar la verificación en dos pasos a través del autenticador para completar esta acción.","Description.Reason":"Los dos pasos de seguridad protegerán tu inicio de sesión, Robux, grandes compras, experiencias y más.","Action.Setup":"Configuración"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ForceAuthenticator");

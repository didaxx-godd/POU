var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.PhoneVerificationChallenge"] = {"Description.ConfirmAbandon":"If you quit verification, you won't be able to complete this action.","Label.RejectAbandon":"Go back","Label.ConfirmAbandon":"Quit","Header.ConfirmAbandon":"Quit verification?"};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.PhoneVerificationChallenge");

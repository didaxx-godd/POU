var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.PrivateAccessTokenChallenge"] = {"Description.VerificationSuccess":"Verification Completed.","Description.VerifyingYouAreNotBot":"Verifying you're not a bot","Description.VerificationError":"Some errors occurred. Please try again."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.PrivateAccessTokenChallenge");

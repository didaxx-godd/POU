var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.ProofOfWorkChallenge"] = {"Description.VerifyingYouAreNotBot":"Verifying you're not a bot","Description.VerificationSuccess":"Verification Completed.","Description.VerificationError":"Some errors occurred. Please try again. "};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.ProofOfWorkChallenge");

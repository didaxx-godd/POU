var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Authentication.LogoutModal"] = {"Heading.SignedOut":"Se cerró la sesión","Body.SignedOutGeneric":"Se cerró la sesión. Para continuar, inicia sesión de nuevo y vuelve a intentarlo.","Body.SignedOutSecurity":"Por tu seguridad, cerramos la sesión. Para continuar, inicia sesión de nuevo y vuelve a intentarlo.","Action.SignIn":"Iniciar sesión","Body.SignInCTA":"Inicia sesión de nuevo y reintenta."};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Authentication.LogoutModal");
